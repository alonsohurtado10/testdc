package com.tutorial.docker_aws;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DockerAwsApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.tutorial.docker_aws;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@RestController
public class DockerAwsApplication {

	@GetMapping("/hola/{nombre}")
	public String holaMundo(@PathVariable("nombre") String nombre){
		return "Hola " + nombre + "!!";
	}

	public static void main(String[] args) {
		SpringApplication.run(DockerAwsApplication.class, args);
	}

}
